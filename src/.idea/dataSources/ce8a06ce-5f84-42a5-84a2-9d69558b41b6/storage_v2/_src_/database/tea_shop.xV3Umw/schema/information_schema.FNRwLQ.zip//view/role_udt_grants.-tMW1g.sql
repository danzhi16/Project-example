create view role_udt_grants (grantor, grantee, udt_catalog, udt_schema, udt_name, privilege_type, is_grantable) as
SELECT grantor,
       grantee,
       udt_catalog,
       udt_schema,
       udt_name,
       privilege_type,
       is_grantable
FROM information_schema.udt_privileges
WHERE (grantor::name IN (SELECT enabled_roles.role_name
                         FROM information_schema.enabled_roles))
   OR (grantee::name IN (SELECT enabled_roles.role_name
                         FROM information_schema.enabled_roles));

alter table role_udt_grants
    owner to postgres;

grant select on role_udt_grants to public;

